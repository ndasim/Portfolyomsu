describe("less.js main tests", function() {
    testLessEqualsInDocument();
});
